# Documentation

## Contributing

Information about contributing to the [README.md](../README.md) live in [CONTRIBUTING.md](CONTRIBUTING.md)

## Changelog

Information about changes live in [CHANGELOG.md](CHANGELOG.md)
