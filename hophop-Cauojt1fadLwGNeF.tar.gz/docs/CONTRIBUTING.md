# Contributing

Contributions are greatly appreciated. Before starting any work, please either comment on an existing issue, or file a new one.

- The pull requests will be accepted into `develop` branch only
- Try to make, and encourage, smaller pull requests
- All modifications or additions should be tested

Thank you for your understanding!
